package com.example.opengl_sensor;


import android.opengl.GLES20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

public class Cube {

    private static final int BYTES_PER_FLOAT = 4;
    private static final int POSITION_DATA_SIZE = 4; // coordinate x, y, z and a dummy
    private static final int  COLOR_DATA_SIZE = 4;
    final int stride = (POSITION_DATA_SIZE + COLOR_DATA_SIZE) * BYTES_PER_FLOAT;

    private final int vertexCount = cubePositions.length / (POSITION_DATA_SIZE + COLOR_DATA_SIZE);

    final FloatBuffer cubePositionsBuffer;
    private ShortBuffer drawListBuffer;

    static float[] cubePositions = { // Using a packed buffer (coordinates and then color)
            -0.5f,  0.5f,  0.0f, 1.0f,  1.0f, 0.0f, 0.0f, 1.0f,
            -0.5f, -0.5f,  0.0f, 1.0f,  0.0f, 1.0f, 0.0f, 1.0f,
             0.5f, -0.5f,  0.0f, 1.0f,  0.0f, 0.0f, 1.0f, 1.0f
    };
    private final int mProgram;
    private int vPMatrixHandle;
    private int mPositionHandle;
    private int mColorHandle;

    // although there is only x y z in the coordinate buffer, opengl will automatically turns it to vec4
    private final String vertexShaderCode =
            "attribute vec4 vPosition;" +
            "attribute vec4 aColor;" +
            "uniform mat4 uMVPMatrix;" +
            "varying vec4 vColor;" +
                    "void main() {" +
                    "  gl_Position = uMVPMatrix * vPosition;" +
                    "  vColor = aColor;" +
                    "  }";

    private final String fragmentShaderCode =
            "precision mediump float;" +
                    "varying vec4 vColor;" +
                    "void main() {" +
                    "  gl_FragColor = vColor;" +
                    "}";
    public Cube() {

       // Allocate a direct block of memory on the native heap
       cubePositionsBuffer = ByteBuffer.allocateDirect(cubePositions.length * BYTES_PER_FLOAT)
       // Floats can be in big-endian or little-endian order.
        .order(ByteOrder.nativeOrder())
       // Give us a floating-point view on this byte buffer.
        .asFloatBuffer();

       // Copy data from the Java heap to the native heap.
        cubePositionsBuffer.put(cubePositions)
       // Reset the buffer position to the beginning of the buffer.
        .position(0);
       // Once the data is on the native heap, we no longer need to keep the float[] array
       // around, and we can let the garbage collector clean it up.

        int vertexShader = CubeRenderer.loadShader(GLES20.GL_VERTEX_SHADER,
                vertexShaderCode);
        int fragmentShader = CubeRenderer.loadShader(GLES20.GL_FRAGMENT_SHADER,
                fragmentShaderCode);

        // create empty OpenGL ES Program
        mProgram = GLES20.glCreateProgram();

        if (mProgram == 0)
            throw new RuntimeException("Error creating program.");

        // add the vertex shader to program
        GLES20.glAttachShader(mProgram, vertexShader);

        // add the fragment shader to program
        GLES20.glAttachShader(mProgram, fragmentShader);

        // creates OpenGL ES program executables
        GLES20.glLinkProgram(mProgram);

    } // constructor

    public void draw(float[] mvpMatrix) { // pass in the calculated transformation matrix
        // Add program to OpenGL ES environment
        GLES20.glUseProgram(mProgram);

        // Pass in the position information
        cubePositionsBuffer.position(0);

        mPositionHandle = GLES20.glGetAttribLocation(mProgram, "vPosition");

        GLES20.glEnableVertexAttribArray(mPositionHandle);
        GLES20.glVertexAttribPointer(mPositionHandle, POSITION_DATA_SIZE,
                GLES20.GL_FLOAT, false, stride, cubePositionsBuffer);

        // Pass in the normal information
        cubePositionsBuffer.position(POSITION_DATA_SIZE);

        mColorHandle = GLES20.glGetAttribLocation(mProgram, "aColor");

        GLES20.glEnableVertexAttribArray(mColorHandle);
        GLES20.glVertexAttribPointer(mColorHandle, COLOR_DATA_SIZE,
                GLES20.GL_FLOAT, false, stride, cubePositionsBuffer);


        // get handle to shape's transformation matrix
        vPMatrixHandle = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix");
        // Pass the projection and view transformation to the shader
        GLES20.glUniformMatrix4fv(vPMatrixHandle, 1, false, mvpMatrix, 0);

        // Draw the triangle
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, vertexCount);
        // will be changed to glDrawElements
        // glDrawArrays submits the vertices in linear order
        // as they are stored in the vertex arrays.
        // With glDrawElements you have to supply an index buffer.
        // Indices allow you to submit the vertices in any order,
        // and to reuse vertices that are shared between triangles.

        // Disable vertex array
        GLES20.glDisableVertexAttribArray(mPositionHandle);
        GLES20.glDisableVertexAttribArray(mColorHandle);

    } // draw

}
