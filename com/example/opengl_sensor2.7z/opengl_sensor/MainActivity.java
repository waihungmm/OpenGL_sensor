package com.example.opengl_sensor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.opengl.GLSurfaceView;

public class MainActivity extends AppCompatActivity {

    private GLSurfaceView gLSurfaceView1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Create a GLSurfaceView instance and set it as the ContentView for this Activity.
        gLSurfaceView1 = new MyGLSurfaceView(this);

        setContentView(gLSurfaceView1);
        // setContentView(R.layout.activity_main);
    }

    @Override
    protected void onResume()
    {
        // The activity must call the GL surface view's onResume() on activity onResume().
        super.onResume();
        gLSurfaceView1.onResume();
    }

    @Override
    protected void onPause()
    {
        // The activity must call the GL surface view's onPause() on activity onPause().
        super.onPause();
        gLSurfaceView1.onPause();
    }
}