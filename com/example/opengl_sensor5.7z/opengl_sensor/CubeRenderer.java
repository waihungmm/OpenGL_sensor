package com.example.opengl_sensor;


import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.util.Log;

/**
 * Class that implements the rendering of cube
 *
 */
public class CubeRenderer implements GLSurfaceView.Renderer {

    // private Triangle mTriangle;
    private Cube mCube;

    float[] sensor_rotation_matrix = new float[16];
    // vPMatrix is an abbreviation for "Model View Projection Matrix"
    private final float[] vPMatrix = new float[16];
    private final float[] projectionMatrix = new float[16];
    private final float[] viewMatrix = new float[16];

    public void onSurfaceCreated(GL10 unused, EGLConfig config) {
        // mTriangle = new Triangle();
        mCube = new Cube();
        // Set the background frame color
        GLES20.glClearColor(0.3f, 0.3f, 0.9f, 1.0f);
    }


    public void onDrawFrame(GL10 unused) {
        float[] modelMatrix = new float[16];
        // Redraw background color
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);

        // Set the camera position (View matrix)
        // I think I should set the orientation here!
        // will be changed to roll pitch yew
        Matrix.setLookAtM(viewMatrix, 0, 0f, 0f, 6f, 0f, 0f, 0f, 0f, 1.0f, 0.0f);

        Matrix.multiplyMM(viewMatrix, 0, sensor_rotation_matrix, 0, viewMatrix, 0);

        // Calculate the projection and view transformation
        Matrix.multiplyMM(vPMatrix, 0, projectionMatrix, 0, viewMatrix, 0);

        // mTriangle.draw(scratch);
        mCube.draw(vPMatrix);

        // draw one more cube
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, 5, 5, 0);
        Matrix.multiplyMM(vPMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(vPMatrix, 0, projectionMatrix, 0, vPMatrix, 0);
        mCube.draw(vPMatrix);

        // draw one more cube
        Matrix.setIdentityM(modelMatrix, 0);
        Matrix.translateM(modelMatrix, 0, -5, -5, 0);
        Matrix.multiplyMM(vPMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(vPMatrix, 0, projectionMatrix, 0, vPMatrix, 0);
        mCube.draw(vPMatrix);


    }

    @Override
    public void onSurfaceChanged(GL10 unused, int width, int height) {
        GLES20.glViewport(0, 0, width, height);

        float ratio = (float) width / height;

        Log.d("App", "onDrawFrame() width="+width+ " height="+height);

        // this projection matrix is applied to object coordinates in the onDrawFrame() method
        // interpretation :  z=-near and z=-far
        // To keep the aspect ratio, ratio should be equal to (right-left) / (top-bottom)
        // near is the focal length (sort of)
        // the original example as bug
        if (ratio > 1.0)
          Matrix.frustumM(projectionMatrix, 0, -ratio * 2, ratio * 2, -2, 2, 3, 9);
        else
          Matrix.frustumM(projectionMatrix, 0, -2, 2, -2 / ratio, 2 / ratio, 3, 9);

    }


    public static int loadShader(int type, String shaderCode){

        // Shader calls should be within a GL thread that is
        // onSurfaceChanged(), onSurfaceCreated() or onDrawFrame()

        // create a vertex shader type (GLES20.GL_VERTEX_SHADER)
        // or a fragment shader type (GLES20.GL_FRAGMENT_SHADER)
        int shader = GLES20.glCreateShader(type);

        // add the source code to the shader and compile it
        GLES20.glShaderSource(shader, shaderCode);
        GLES20.glCompileShader(shader);

        return shader;
    }

    public volatile float mAngle;

    public float getAngle() {
        return mAngle;
    }

    public void setAngle(float angle) {
        mAngle = angle;
    }

    public void  update_rotation_matrix(float[] R)
    {
      sensor_rotation_matrix = R.clone();
    }

}
